# HealthGuard Phase 1 — Vulnerability Analysis Script

## Student
Somto Collins | Early Code Institute, Kubwa Abuja | SIWES Cybersecurity Training | May 2026

## Description
Parses the Nessus vulnerability scan CSV, computes weighted risk scores for each host,
normalises scores to 0-100, and prints a ranked table with likely attacker entry points.

## Scoring Formula
Raw Score = (Critical x 10) + (High x 5) + (Medium x 2) + (Low x 0.5)
Normalised Score = (Raw Score / Max Raw Score) x 100

## How to Run
Run from inside the phase_templates/ directory:

    cd healthguard-soc-lab/students/student-a/phase_templates
    python phase1_python_starter.py

## Requirements
- Python 3.x (no external libraries needed)
- nessus_scan.csv must be located at ../nessus_scan.csv relative to the script

## Expected Output
- Ranked vulnerability risk table for all 10 hosts
- Likely attacker entry points based on risk scores
