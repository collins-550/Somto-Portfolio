#!/usr/bin/env python3
import csv
import sys
from collections import defaultdict

NESSUS_CSV = "../nessus_scan.csv"

WEIGHTS = {"Critical": 10, "High": 5, "Medium": 2, "Low": 0.5, "None": 0, "Info": 0}

def load_nessus(filepath):
    findings = []
    with open(filepath, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            findings.append(row)
    return findings

def compute_host_scores(findings):
    host_data = defaultdict(lambda: {
        "hostname": "", "critical": 0, "high": 0,
        "medium": 0, "low": 0, "raw_score": 0.0
    })
    for finding in findings:
        ip   = finding.get("Host", "").strip()
        risk = finding.get("Risk", "None").strip()
        host_data[ip]["hostname"] = ip
        if risk == "Critical":
            host_data[ip]["critical"] += 1
        elif risk == "High":
            host_data[ip]["high"] += 1
        elif risk == "Medium":
            host_data[ip]["medium"] += 1
        elif risk == "Low":
            host_data[ip]["low"] += 1
    for data in host_data.values():
        data["raw_score"] = (
            data["critical"] * 10 +
            data["high"]     *  5 +
            data["medium"]   *  2 +
            data["low"]      *  0.5
        )
    return dict(host_data)

def normalise_scores(host_data):
    if not host_data:
        return host_data
    max_raw = max(d["raw_score"] for d in host_data.values())
    if max_raw == 0:
        for d in host_data.values():
            d["score"] = 0.0
        return host_data
    for data in host_data.values():
        data["score"] = round((data["raw_score"] / max_raw) * 100, 1)
    return host_data

def print_report(host_data):
    ranked = sorted(host_data.items(),
                    key=lambda x: x[1].get("score", 0), reverse=True)

    sep = "=" * 65
    print(f"\n{sep}")
    print("  HEALTHGUARD NETWORK — VULNERABILITY RISK RANKING")
    print(sep)
    print(f"  {'Rank':<6}{'IP':<16}{'Hostname':<16}{'Crit':>5}{'High':>5}{'Med':>5}{'Score':>8}")
    print(f"  {'-'*60}")
    for rank, (ip, data) in enumerate(ranked, 1):
        print(f"  {rank:<6}{ip:<16}{data['hostname']:<16}"
              f"{data['critical']:>5}{data['high']:>5}"
              f"{data['medium']:>5}{data.get('score', 0):>8.1f}")
    print(sep)

    # Entry points
    top2 = ranked[:2]
    print(f"\n{'=' * 65}")
    print("  LIKELY ATTACKER ENTRY POINTS")
    print(f"{'=' * 65}")
    for i, (ip, data) in enumerate(top2, 1):
        print(f"\n  {i}. IP: {ip}")
        print(f"     Score : {data.get('score', 0):.1f}")
        print(f"     Critical vulns : {data['critical']}")
        print(f"     High vulns     : {data['high']}")
    print()

def main():
    print(f"Loading {NESSUS_CSV}...")
    try:
        findings = load_nessus(NESSUS_CSV)
    except FileNotFoundError:
        print(f"Error: {NESSUS_CSV} not found. "
              "Are you running from the student-a/ directory?")
        sys.exit(1)

    print(f"Loaded {len(findings)} findings.\n")
    host_data = compute_host_scores(findings)
    host_data = normalise_scores(host_data)
    print_report(host_data)

if __name__ == "__main__":
    main()
